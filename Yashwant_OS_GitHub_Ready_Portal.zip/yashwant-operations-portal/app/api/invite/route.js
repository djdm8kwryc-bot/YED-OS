import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
export async function POST(request){
 try {
  const url=process.env.NEXT_PUBLIC_SUPABASE_URL, publicKey=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, serviceKey=process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!url||!publicKey||!serviceKey)return NextResponse.json({error:'Server credentials missing'},{status:503});
  const token=request.headers.get('authorization')?.replace(/^Bearer\s+/i,'');
  if(!token)return NextResponse.json({error:'Unauthorized'},{status:401});
  const publicClient=createClient(url,publicKey,{auth:{autoRefreshToken:false,persistSession:false}});
  const {data:userData,error:authErr}=await publicClient.auth.getUser(token);
  if(authErr||!userData.user)return NextResponse.json({error:'Unauthorized'},{status:401});
  const admin=createClient(url,serviceKey,{auth:{autoRefreshToken:false,persistSession:false}});
  const {data:actor}=await admin.from('profiles').select('role').eq('id',userData.user.id).single();
  if(!['owner','coordinator'].includes(actor?.role))return NextResponse.json({error:'Forbidden'},{status:403});
  const body=await request.json();
  const email=String(body.email||'').trim().toLowerCase(),name=String(body.full_name||'').trim(),role=String(body.role||'staff');
  const roles=['coordinator','designer','marketer','videographer','telecaller','sales','staff'];
  if(!/^\S+@\S+\.\S+$/.test(email)||name.length<2||!roles.includes(role))return NextResponse.json({error:'Invalid staff details'},{status:400});
  if(actor.role==='coordinator'&&role==='coordinator')return NextResponse.json({error:'Only owner can invite coordinators'},{status:403});
  const {data,error}=await admin.auth.admin.inviteUserByEmail(email,{data:{full_name:name},redirectTo:new URL('/',request.url).toString()});
  if(error)return NextResponse.json({error:error.message},{status:400});
  const {error:updateErr}=await admin.from('profiles').upsert({id:data.user.id,email,full_name:name,role},{onConflict:'id'});
  if(updateErr)return NextResponse.json({error:'Invitation sent but role setup failed; fix in Supabase',detail:updateErr.message},{status:500});
  return NextResponse.json({ok:true});
 }catch(e){return NextResponse.json({error:e.message||'Server error'},{status:500})}
}
