// Optional generic adapter. Do not enable before your call provider is configured to send this payload.
// POST body: {provider_call_id,staff_email,lead_id?,state,outcome?,started_at?,ended_at?,duration_sec?}
// Signature header: x-yashwant-signature = HMAC SHA256 hex of RAW JSON body using TELEPHONY_WEBHOOK_SECRET.
import { NextResponse } from 'next/server';
import { createHmac,timingSafeEqual } from 'crypto';
import { createClient } from '@supabase/supabase-js';
export async function POST(request){
 try{
  const secret=process.env.TELEPHONY_WEBHOOK_SECRET,key=process.env.SUPABASE_SERVICE_ROLE_KEY,url=process.env.NEXT_PUBLIC_SUPABASE_URL;
  if(!secret||!key||!url)return NextResponse.json({error:'Not configured'},{status:503});
  const body=await request.text(), expected=createHmac('sha256',secret).update(body).digest('hex');
  const given=(request.headers.get('x-yashwant-signature')||'').replace(/^sha256=/,'').trim();
  if(!/^[a-f0-9]{64}$/i.test(given)||!timingSafeEqual(Buffer.from(expected,'hex'),Buffer.from(given,'hex')))return NextResponse.json({error:'Invalid signature'},{status:401});
  const x=JSON.parse(body),admin=createClient(url,key,{auth:{autoRefreshToken:false,persistSession:false}});
  if(!x.provider_call_id||!x.staff_email||!['dialing','ringing','in_progress','completed','missed','failed'].includes(x.state))return NextResponse.json({error:'Invalid call payload'},{status:400});
  const {data:staff}=await admin.from('profiles').select('id').eq('email',String(x.staff_email).toLowerCase()).single();
  if(!staff)return NextResponse.json({error:'Unknown staff'},{status:404});
  const rec={provider_call_id:String(x.provider_call_id),staff_id:staff.id,lead_id:x.lead_id||null,source:'provider',state:x.state,outcome:['connected','no_answer','busy','follow_up','visit_booked','demo_booked','wrong_number','other'].includes(x.outcome)?x.outcome:'other',duration_sec:Math.max(0,Number(x.duration_sec||0)),started_at:x.started_at||new Date().toISOString(),ended_at:x.ended_at||null,notes:'Provider-synced event'};
  const {error}=await admin.from('call_logs').upsert(rec,{onConflict:'provider_call_id'});
  if(error)return NextResponse.json({error:error.message},{status:400});
  return NextResponse.json({ok:true});
 }catch(e){return NextResponse.json({error:e.message||'Invalid request'},{status:400})}
}
