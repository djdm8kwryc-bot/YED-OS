import './globals.css';
export const metadata={title:'Yashwant OS | Business Command Center',description:'Owner, coordinator, creative team and telecalling management portal'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
