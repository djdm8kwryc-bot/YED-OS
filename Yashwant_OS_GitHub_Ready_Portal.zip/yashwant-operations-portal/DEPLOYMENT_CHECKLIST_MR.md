# Yashwant OS — सुरू करण्याचे टप्पे

1. ZIP extract करा आणि GitHub मध्ये **private repository** तयार करा.
2. Supabase मध्ये नवीन project तयार करा; `supabase/schema.sql` चालवा.
3. तुमचे Owner account Supabase Authentication मध्ये तयार करा. README मधील SQL ने Role **owner** करा.
4. Supabase Project URL, public anon key आणि **server-only service-role key** Vercel Environment Variables मध्ये ठेवा. Secret public repo मध्ये टाकू नका.
5. Vercel मधून GitHub repo deploy करून HTTPS लिंक मिळवा.
6. Login केल्यावर **Admin & Import** मधून `data/content_import.csv` आणि `data/campaign_import.csv` import करा.
7. Swarali (Coordinator), Sakshi (Designer), Digital Marketer, Videographer, Rekha (Telecaller), Sales team यांना Invite करा.
8. Coordinator **Task Board** मधून रोज assignments देतील आणि पुढील 8 दिवसांचे calendar assignments generate करतील.
9. Owner Dashboard वरून Pending/Completed Tasks, Leads, Calling, Campaign Budget आणि Staff Activity दिसतील.
10. प्रत्यक्ष **कॉल सुरू आहे का** यासाठी cloud telephony provider चे अधिकृत integration आवश्यक आहे; फक्त manual call log वरून live call confirm करता येत नाही.

> सध्याचा ZIP हा deployment-ready starter source आहे; प्रत्यक्ष live website / GitHub repository तयार झालेले नाही.
