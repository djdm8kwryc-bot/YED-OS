-- Execute once in Supabase SQL Editor. Auth users are invited from the Portal after owner setup.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '',
 email text not null default '',
 role text not null default 'staff' check(role in ('owner','coordinator','designer','marketer','videographer','telecaller','sales','staff')),
 created_at timestamptz not null default now()
);
create or replace function public.new_profile() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.profiles(id,email,full_name,role)
 values(new.id,coalesce(new.email,''),coalesce(new.raw_user_meta_data->>'full_name',split_part(coalesce(new.email,''),'@',1)),'staff')
 on conflict(id) do nothing;
 return new;
end $$;
drop trigger if exists auth_user_created on auth.users;
create trigger auth_user_created after insert on auth.users for each row execute procedure public.new_profile();

create or replace function public.my_role() returns text language sql stable security definer set search_path='' as $$
 select role from public.profiles where id=(select auth.uid())
$$;
create or replace function public.is_manager() returns boolean language sql stable security definer set search_path='' as $$
 select coalesce(public.my_role() in ('owner','coordinator'),false)
$$;

create table if not exists public.tasks (
 id uuid primary key default gen_random_uuid(), source_key text unique, title text not null, description text default '', business text not null,
 task_type text not null default 'general' check(task_type in ('general','design','video','marketing','sales','calling','approval')),
 assigned_to uuid references public.profiles(id), created_by uuid references public.profiles(id),
 due_date date, priority text not null default 'medium' check(priority in ('low','medium','high','urgent')),
 status text not null default 'todo' check(status in ('todo','in_progress','review','done','blocked')),
 target_quantity int not null default 1 check(target_quantity>=0), completed_quantity int not null default 0 check(completed_quantity>=0),
 notes text default '', evidence_url text default '', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create or replace function public.guard_task_assignment() returns trigger language plpgsql set search_path='' as $$
begin
 if not public.is_manager() and (
   new.source_key is distinct from old.source_key or new.title is distinct from old.title or new.description is distinct from old.description or
   new.business is distinct from old.business or new.task_type is distinct from old.task_type or
   new.assigned_to is distinct from old.assigned_to or new.created_by is distinct from old.created_by or
   new.due_date is distinct from old.due_date or new.priority is distinct from old.priority or
   new.target_quantity is distinct from old.target_quantity
 ) then raise exception 'Only owner/coordinator can change task assignment or targets'; end if;
 new.updated_at=now();return new;
end $$;
drop trigger if exists protect_task_assignment on public.tasks;
create trigger protect_task_assignment before update on public.tasks for each row execute procedure public.guard_task_assignment();

create table if not exists public.content_items (
 id uuid primary key default gen_random_uuid(),external_id text unique not null,business text not null,
 kind text not null check(kind in ('reel','post')),format text default 'reel',title text not null,
 publish_at timestamptz not null,assign_at date not null,brief text default '',
 assigned_to uuid references public.profiles(id),shoot_at timestamptz,shoot_location text default '',
 asset_url text default '',status text not null default 'planned' check(status in ('planned','assigned','shooting','editing','review','approved','published','blocked')),
 posted_url text default '', updated_at timestamptz not null default now()
);
create table if not exists public.campaigns (
 id uuid primary key default gen_random_uuid(),external_id text unique not null,business text not null,title text not null,
 start_date date not null,end_date date not null,daily_budget numeric(12,2) not null default 0,
 planned_budget numeric(12,2) not null default 0,actual_spend numeric(12,2) not null default 0,
 leads_generated int not null default 0,qualified_leads int not null default 0,
 status text not null default 'planned' check(status in ('planned','active','paused','completed')),
 objective text default '',ad_link text default '',updated_at timestamptz not null default now()
);
create table if not exists public.leads (
 id uuid primary key default gen_random_uuid(),full_name text not null,phone text not null,business text not null,
 source text default 'other',campaign_id text, assigned_to uuid references public.profiles(id),
 stage text not null default 'new' check(stage in ('new','contacted','qualified','visit_booked','visit_done','demo_booked','won','lost')),
 notes text default '',next_followup_at timestamptz,created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.call_logs (
 id uuid primary key default gen_random_uuid(),lead_id uuid references public.leads(id) on delete set null,
 staff_id uuid not null references public.profiles(id),provider_call_id text unique,
 source text not null default 'manual' check(source in ('manual','provider')),
 state text not null default 'completed' check(state in ('dialing','ringing','in_progress','completed','missed','failed')),
 outcome text not null default 'other' check(outcome in ('connected','no_answer','busy','follow_up','visit_booked','demo_booked','wrong_number','other')),
 duration_sec int not null default 0 check(duration_sec>=0),notes text default '',
 started_at timestamptz not null default now(),ended_at timestamptz,created_at timestamptz not null default now()
);
create table if not exists public.work_sessions (
 id uuid primary key default gen_random_uuid(),staff_id uuid not null references public.profiles(id),
 started_at timestamptz not null default now(),ended_at timestamptz,
 note text default '',created_at timestamptz not null default now()
);
create unique index if not exists one_open_shift_per_staff on public.work_sessions(staff_id) where ended_at is null;
create table if not exists public.presence (
 staff_id uuid primary key references public.profiles(id) on delete cascade,
 last_seen_at timestamptz not null default now(),is_active boolean not null default false,
 updated_at timestamptz not null default now()
);


-- Editable monthly per-employee targets, compared in UI with verified portal records.
create table if not exists public.monthly_targets (
 id uuid primary key default gen_random_uuid(), staff_id uuid not null references public.profiles(id),
 month text not null check(month ~ '^20[0-9]{2}-(0[1-9]|1[0-2])$'),
 metric text not null check(metric in ('tasks_assigned','videos_completed','designs_completed','marketing_completed','calls_logged','tasks_completed','leads_won')),
 target_value int not null default 0 check(target_value>=0),
 notes text default '',created_at timestamptz not null default now(),
 unique(staff_id,month,metric)
);
create or replace function public.guard_content_fields() returns trigger language plpgsql set search_path='' as $$
begin
 if not public.is_manager() and (
  new.external_id is distinct from old.external_id or new.business is distinct from old.business or
  new.kind is distinct from old.kind or new.format is distinct from old.format or
  new.title is distinct from old.title or new.publish_at is distinct from old.publish_at or
  new.assign_at is distinct from old.assign_at or new.brief is distinct from old.brief or
  new.assigned_to is distinct from old.assigned_to
 ) then raise exception 'Only owner/coordinator can alter content schedule or assignment'; end if;
 return new;
end $$;
drop trigger if exists content_field_guard on public.content_items;
create trigger content_field_guard before update on public.content_items for each row execute procedure public.guard_content_fields();
create or replace function public.guard_lead_fields() returns trigger language plpgsql set search_path='' as $$
begin
 if not public.is_manager() and (
 new.full_name is distinct from old.full_name or new.phone is distinct from old.phone or
 new.business is distinct from old.business or new.source is distinct from old.source or
 new.campaign_id is distinct from old.campaign_id or new.assigned_to is distinct from old.assigned_to
 ) then raise exception 'Only owner/coordinator can reassign or edit lead identity'; end if;
 return new;
end $$;
drop trigger if exists lead_field_guard on public.leads;
create trigger lead_field_guard before update on public.leads for each row execute procedure public.guard_lead_fields();
create or replace function public.guard_campaign_fields() returns trigger language plpgsql set search_path='' as $$
begin
 if not public.is_manager() and (
 new.external_id is distinct from old.external_id or new.business is distinct from old.business or
 new.title is distinct from old.title or new.start_date is distinct from old.start_date or
 new.end_date is distinct from old.end_date or new.daily_budget is distinct from old.daily_budget or
 new.planned_budget is distinct from old.planned_budget or new.objective is distinct from old.objective
 ) then raise exception 'Only owner/coordinator can change the approved campaign plan'; end if;
 return new;
end $$;
drop trigger if exists campaign_field_guard on public.campaigns;
create trigger campaign_field_guard before update on public.campaigns for each row execute procedure public.guard_campaign_fields();

alter table public.monthly_targets enable row level security;
alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.content_items enable row level security;
alter table public.campaigns enable row level security;
alter table public.leads enable row level security;
alter table public.call_logs enable row level security;
alter table public.work_sessions enable row level security;
alter table public.presence enable row level security;

drop policy if exists targets_read on public.monthly_targets;
create policy targets_read on public.monthly_targets for select to authenticated using(public.is_manager() or staff_id=(select auth.uid()));
drop policy if exists targets_insert on public.monthly_targets;
create policy targets_insert on public.monthly_targets for insert to authenticated with check(public.is_manager());
drop policy if exists targets_update on public.monthly_targets;
create policy targets_update on public.monthly_targets for update to authenticated using(public.is_manager()) with check(public.is_manager());

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using(true); -- Visible staff name/role only, not secrets.
-- Profiles changed only by privileged server-side invitation or explicit owner SQL.

drop policy if exists tasks_read on public.tasks;
create policy tasks_read on public.tasks for select to authenticated using(public.is_manager() or assigned_to=(select auth.uid()) or created_by=(select auth.uid()));
drop policy if exists tasks_insert on public.tasks;
create policy tasks_insert on public.tasks for insert to authenticated with check(public.is_manager() and created_by=(select auth.uid()));
drop policy if exists tasks_update on public.tasks;
create policy tasks_update on public.tasks for update to authenticated using(public.is_manager() or assigned_to=(select auth.uid())) with check(public.is_manager() or assigned_to=(select auth.uid()));

drop policy if exists content_read on public.content_items;
create policy content_read on public.content_items for select to authenticated using(true); -- Portfolio content is shared with staff.
drop policy if exists content_insert on public.content_items;
create policy content_insert on public.content_items for insert to authenticated with check(public.is_manager() or public.my_role()='marketer');
drop policy if exists content_update on public.content_items;
create policy content_update on public.content_items for update to authenticated using(public.is_manager() or assigned_to=(select auth.uid()) or public.my_role()='marketer') with check(public.is_manager() or assigned_to=(select auth.uid()) or public.my_role()='marketer');

drop policy if exists campaigns_read on public.campaigns;
create policy campaigns_read on public.campaigns for select to authenticated using(true);
drop policy if exists campaigns_insert on public.campaigns;
create policy campaigns_insert on public.campaigns for insert to authenticated with check(public.is_manager() or public.my_role()='marketer');
drop policy if exists campaigns_update on public.campaigns;
create policy campaigns_update on public.campaigns for update to authenticated using(public.is_manager() or public.my_role()='marketer') with check(public.is_manager() or public.my_role()='marketer');

drop policy if exists leads_read on public.leads;
create policy leads_read on public.leads for select to authenticated using(public.is_manager() or assigned_to=(select auth.uid()));
drop policy if exists leads_insert on public.leads;
create policy leads_insert on public.leads for insert to authenticated with check(public.is_manager() or assigned_to=(select auth.uid()));
drop policy if exists leads_update on public.leads;
create policy leads_update on public.leads for update to authenticated using(public.is_manager() or assigned_to=(select auth.uid())) with check(public.is_manager() or assigned_to=(select auth.uid()));

drop policy if exists calls_read on public.call_logs;
create policy calls_read on public.call_logs for select to authenticated using(public.is_manager() or staff_id=(select auth.uid()));
drop policy if exists calls_insert on public.call_logs;
create policy calls_insert on public.call_logs for insert to authenticated with check(staff_id=(select auth.uid()) and source='manual' and state in ('completed','missed','failed'));
-- Manually-entered call records are immutable; corrections require a supervisor via server admin tool.

drop policy if exists shifts_read on public.work_sessions;
create policy shifts_read on public.work_sessions for select to authenticated using(public.is_manager() or staff_id=(select auth.uid()));
drop policy if exists shifts_insert on public.work_sessions;
create policy shifts_insert on public.work_sessions for insert to authenticated with check(staff_id=(select auth.uid()));
drop policy if exists shifts_update on public.work_sessions;
create policy shifts_update on public.work_sessions for update to authenticated using(staff_id=(select auth.uid())) with check(staff_id=(select auth.uid()));

drop policy if exists presence_read on public.presence;
create policy presence_read on public.presence for select to authenticated using(public.is_manager() or staff_id=(select auth.uid()));
drop policy if exists presence_insert on public.presence;
create policy presence_insert on public.presence for insert to authenticated with check(staff_id=(select auth.uid()));
drop policy if exists presence_update on public.presence;
create policy presence_update on public.presence for update to authenticated using(staff_id=(select auth.uid())) with check(staff_id=(select auth.uid()));

-- Let supervisors receive realtime changes. Tables are also refreshed on a 30s interval.
do $$ begin
 alter publication supabase_realtime add table public.tasks,public.content_items,public.campaigns,public.leads,public.call_logs,public.work_sessions,public.presence;
exception when duplicate_object then null;
end $$;
