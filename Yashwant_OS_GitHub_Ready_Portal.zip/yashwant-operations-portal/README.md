# Yashwant OS · Business Command Center

A GitHub-ready **Next.js + Supabase** staff operations portal built for:

1. VenuGopal Park (row houses)
2. Shri Shankar Swami Park (NA plots)
3. UrbanEye Surveillance (live night CCTV monitoring)
4. Arisha Silvers (online jewellery)
5. MSK Saraf (local jewellery)

### What works after setup

- **Owner dashboard:** tasks, overdue items, progress, leads, daily call logs, recorded campaign spend and employee availability.
- **Coordinator (Swarali):** assign and reassign tasks; specify due date, business, priority and quantity targets; review work, and generate upcoming content-linked assignments.
- **Graphic designer (Sakshi):** content calendar with reel covers, post/carousel work and two-day-before-posting assignment dates.
- **Videographer:** 300 reel shoot schedule, video task board and production status.
- **Digital marketer:** 825 content assets, scheduled posting times and 34 paid campaigns with editable spend, leads and campaign status.
- **Telecaller (Rekha):** assigned leads, manual call logs, outcomes, daily call totals and follow-ups.
- **Staff online presence:** 25-second visible browser heartbeat, 90-second online expiry, recent interaction indicator and manual start/stop work sessions.
- **Permissions:** Supabase Auth and Postgres Row Level Security (RLS).
- **Exports:** CSV downloads for major operational tables.

**No real customer/calling data is prefilled.** The included CSVs are a one-time import of *planning* documents, not execution history.

## 1. Local installation

```bash
npm install
cp .env.example .env.local
```

Create a Supabase project and insert these values into `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-public-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-secret-server-only-service-role-key
TELEPHONY_WEBHOOK_SECRET=optional-long-secret
```

**Never** put the service-role key in browser code, a public GitHub repository, or a variable named `NEXT_PUBLIC_*`.

## 2. Database and first owner

1. Supabase → **SQL Editor**, run all of `supabase/schema.sql`.
2. Supabase → **Authentication → Users → Add user**: create the owner's email/password.
3. Supabase → **SQL Editor**, set exactly that account's owner role (replace the email):

```sql
update public.profiles
set role='owner', full_name='Business Owner'
where email='owner@example.com';
```

4. Supabase → Authentication → Settings: **disable public sign-ups**, or use a strict invite-only configuration; staff should be invited from the portal. Verify your email templates and redirect URL allow the deployed site's password setup flow.
5. Start the portal with `npm run dev`, open http://localhost:3000 and log in.

**Invitation mail note:** Supabase-hosted default email sending is limited; configure your own SMTP for multiple employee accounts. `POST /api/invite` validates the session server-side, checks the requester role, sends an invitation and creates the matching employee profile.

## 3. Upload your content plans

In the portal, open **Admin & Import** and import:

- `data/content_import.csv` — **300 reels + 525 posts/carousels = 825 entries** (unique IDs and scheduled IST dates/times, designer assignment two days earlier).
- `data/campaign_import.csv` — **34 video advertising campaigns**, including start/end dates and *recommended* planned media budgets.

The source PDFs use overlapping **but inconsistent campaign ID definitions** in different books. This portal deliberately uses the campaign **master** PDF as authoritative for the paid campaigns, and the **300 detailed reels** book for organic reel dates/topics. Later ads should be approved against the correct campaign dates; do not assume every reel's embedded paid-tag refers to the master campaign of the same ID.

Every record is imported by `external_id`; repeated import updates existing matching records. **CAUTION:** reimport resets fields included in CSV such as `status`; do not reimport after editing actual progress unless you intend to reset status. The import does not automatically assign real employees until you select staff or generate assignments.

## 4. Coordinator operations

1. Invite the coordinator, designer, marketer, videographer, telecaller and sales staff using real work emails.
2. Invite-only employee roles control which parts of the database staff can edit.
3. On **Task Board**, click **New Assignment** to set type, deadline, priority, employee, quantity target and instructions.
4. On **Content Calendar**, see the posting date and **two-day-before assignment date**.
5. On **Task Board**, click **Generate next 8 days from calendar**. The portal creates one design and one publishing assignment per content item, plus a videographer shoot/edit assignment for reels. It picks the first available person with each role; the coordinator should review and reassign to the appropriate employee. It does **not** send push notifications; employees see their tasks upon login.
6. Mark task status, completed units and evidence as work progresses. Owner uses Reports to compare target units with completed units.

**Important lead-time nuance:** A two-day handoff may be insufficient for filming/paid hero ads; use an earlier due date for campaign videos, shoot bookings and hero assets. Paid launch packs in the original scripts call for earlier sign-off.

## 5. Calling proof: important distinction

The portal shows **calls logged**, *not* verified calls unless your calling platform is connected. Employees can enter manual call records. Such records are labeled `manual` and should not be treated as proof of real phone activity.

For a cloud telephony/PBX provider, adapt it to the optional endpoint `POST /api/telephony`:

- send the actual webhook payload fields `{ provider_call_id, staff_email, lead_id, state, outcome, started_at, ended_at, duration_sec }`;
- include `x-yashwant-signature` equal to the **hex SHA-256 HMAC of the raw request body**, signed with `TELEPHONY_WEBHOOK_SECRET`;
- supported states: `dialing`, `ringing`, `in_progress`, `completed`, `missed`, `failed`;
- configure the provider to emit both started and completed events with a stable provider call ID;
- **mapping a telephony provider's payload into this schema and confirming caller identity is a separate integration step.** The app does not silently access personal phones or recordings.

Review consent, staff notice and applicable laws before integrating phone records, recordings or location data. The service never records microphones or hidden screen activity.

## 6. How availability works

| Badge | What it really means |
|---|---|
| Active | Portal was open/visible and a click or keyboard interaction was seen in the previous 2 minutes |
| Idle | A visible heartbeat was seen within 90 seconds, but no recent click/keyboard interaction |
| Offline | No heartbeat in 90 seconds (or device disconnected) |
| Work session running | Employee manually pressed **Start Work**; this is not proof of productivity |
| Call in progress | Only provider-confirmed phone calls, if a telephony provider is configured |

The client-side app presence is meant for **work coordination**, not covert surveillance or payroll verification.

## 7. GitHub + website deployment

1. Create a **private** GitHub repository named `yashwant-operations-portal`.
2. Extract this ZIP and run in its folder:

```bash
git init
git add .
git commit -m "Initial Yashwant OS operations portal"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/yashwant-operations-portal.git
git push -u origin main
```

3. Open **Vercel → New Project**, import the GitHub repository.
4. Set environment variables from `.env.example` (real values) in Vercel **Project Settings → Environment Variables**.
5. Deploy and use the generated HTTPS website link for owner/team login.
6. Configure Supabase Auth `Site URL` / allowed redirects to your deployed domain; verify invites and password setup.
7. Set the app to **invite-only** before onboarding live staff or leads.

This ZIP does **not** include a hosted GitHub repo or deployed URL. Those require connecting your own accounts.

## Security and production checklist

- The system uses database RLS and server-side invitation verification, but is a **working starter**, not an independently audited production system.
- Review and strengthen `supabase/schema.sql` policies/triggers before operating with sensitive customer data.
- Restrict privileged exports and staff visibility according to your local requirements; decide what data employees may see.
- Confirm Supabase email sender, enforce MFA for privileged accounts if available, and keep service credentials private.
- For a complete system, add: audit logs, push/email notifications, telephony provider integration, file upload approval, lead deduplication, granular project restrictions, automated backups and retention rules.
- Source campaign plan is recommended spend, not actual spending. The portal clearly separates planned/actual.
- Employee presence is a coordination indicator, not attendance proof. Recorded completion is distinguishable from any marketing KPI or sales outcome.

## Reference material

Data extracts are generated by `scripts/extract_content.py` from the original user-provided PDFs. Those source PDFs are not redistributed in this code package. Re-running that script requires placing those exact PDFs in `/mnt/data`, as in the authoring environment.

### Monthly role targets

In **Reports → Monthly individual targets**, the owner/coordinator can set a numeric KPI for each employee for October 2026 through April 2027. Examples:

- Swarali / Coordinator → `tasks_assigned` (created tasks in that month).
- Videographer → `videos_completed` (assigned video tasks marked done in that month).
- Sakshi / Designer → `designs_completed` (assigned design tasks marked done in that month).
- Digital Marketer → `marketing_completed` (assigned marketing/publishing tasks marked done).
- Rekha / Telecaller → `calls_logged` (recorded calls—provider-verified only after integration).
- Sales → `leads_won` (assigned leads at won status that were last updated in the month).

`data/monthly_target_guide.csv` gives **planning benchmarks**, based on your content volume, not contractual employee quotas. Review employee count, capacity and call availability before adopting them. Staff progress is calculated from real records, not a fabricated demo result.

### First login for an invited employee

The invite is sent with a redirect to the portal homepage. The invite link may establish an authenticated session via Supabase; then employees should open **My Account** and set a personal password of 12+ characters. Supabase Authentication Site URL and Redirect URLs must be configured for the deployed host. Production SMTP configuration and email template testing are required.
