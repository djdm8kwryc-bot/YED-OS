import re,csv,fitz,datetime,pathlib
R=pathlib.Path(__file__).parents[1]; D=pathlib.Path('/mnt/data')
RFILE=fitz.open(str(D/'Yashwant_300_Detailed_Reel_Scripts(1).pdf'))
PFILE=fitz.open(str(D/'Yashwant_Hinglish_Posts_Carousels_Compact_More_Detailed(1).pdf'))
CFILE=fitz.open(str(D/'Yashwant_Campaign_Video_Shooting_Scripts_Master_Oct2026_Apr2027.pdf'))
names={'VG':'VenuGopal Park','SS':'Shri Shankar Swami Park','UE':'UrbanEye Surveillance','AS':'Arisha Silvers','MSK':'MSK Saraf','AR':'Arisha Silvers'}
ptime={'VG':'19:30','SS':'19:00','UE':'11:30','AS':'20:00','MSK':'18:30'}
def dt(s):return datetime.datetime.strptime(s,'%d %b %Y').date()
def moment(d,t):return f'{d.isoformat()}T{t}:00+05:30'
def record(ext,business,kind,title,posted,brief,format='reel'):
 return {'external_id':ext,'business':business,'kind':kind,'title':title,'publish_at':posted,'assign_at':(datetime.datetime.fromisoformat(posted).date()-datetime.timedelta(days=2)).isoformat(),'brief':brief[:900],'format':format,'status':'planned'}
reels=[]
for page in range(4,14):
 for block in RFILE[page].get_text('blocks'):
  s=block[4].strip(); m=re.match(r'^(VG|SS|UE|AS|MSK)-R(\d{2})\n(\d{2} \w{3} 20\d{2})\n(.+?)\n\d+\s*$',s,re.S)
  if m:
   prefix,num,d,title=m.groups(); title=title.replace('\n',' ').strip()
   reels.append(record(f'{prefix}-R{num}',names[prefix],'reel',title,moment(dt(d),ptime[prefix]),f'Source: 300 Detailed Reel Scripts, {prefix}-R{num}. Edit full organic reel, subtitles, cover thumbnail, 3 story frames, pop-ups and CTA. Verify facts, footage and script; separately prepare paid cut if marked.'))
print('REELS',len(reels),{x['business']:sum(y['business']==x['business'] for y in reels) for x in reels[:1]})
posts=[]
for page in range(1,36):
 blocks=PFILE[page].get_text('blocks'); h=blocks[0][4]; hparts=h.splitlines(); business=hparts[0].strip(); mm=re.search(r'(October|November|December|January|February|March|April)\s+(20\d{2})',h)
 if not mm: print('missing header',page,h[:150]); continue
 mon,yr=mm.groups()
 for b in blocks[1:]:
  txt=b[4].strip(); head=re.match(r'^(\d{1,2})\.\s+(.+)',txt)
  if not head:continue
  idx=int(head.group(1)); lines=txt.splitlines()
  dtidx=next((i for i,x in enumerate(lines) if re.search(r'\b\d{1,2}\s+[A-Z][a-z]{2}\s+\d{1,2}:\d{2}\s+(?:AM|PM)\s*\|\s*(?:Static|Carousel)',x)),None)
  if dtidx is None:print('missing date',business,mon,idx,lines[:4]);continue
  dataline=lines[dtidx]; timepat=re.search(r'(\d{1,2})\s+([A-Z][a-z]{2})\s+(\d{1,2}:\d{2})\s+(AM|PM)\s*\|\s*(Static|Carousel)\s*\|\s*([\w-]+)',dataline)
  if not timepat:print('unparsed date',dataline);continue
  day,mname,clock,ampm,kind,mode=timepat.groups(); ts=datetime.datetime.strptime(f'{day} {mname} {yr} {clock} {ampm}','%d %b %Y %I:%M %p')
  title=' '.join(lines[0:dtidx]);title=re.sub(r'^\d{1,2}\.\s*','',title).strip()
  prefix=next((k for k,v in names.items() if v.lower()==business.lower()),'XX')
  content=re.sub(r'\s+',' ', ' '.join(lines[dtidx+1:]))
  posts.append(record(f'{prefix}-P{yr}{ts.month:02d}-{idx:02d}',names.get(prefix,business),'post',title,moment(ts.date(),ts.strftime('%H:%M')),f'{kind} / {mode}. {content}',kind.lower()))
print('POSTS',len(posts))
camps=[]
for page in range(2,7):
 business=CFILE[page].get_text('blocks')[0][4].split(' - Campaign')[0].strip()
 bs=CFILE[page].get_text('blocks')
 for j,b in enumerate(bs):
  s=b[4].strip()
  match=re.match(r'^((?:VG|SS|UE|AR|MSK)-\d{2})\n(.+?)\n(\d{2} \w{3} 20\d{2})\n(\d{2} \w{3} 20\d{2})\nRs\.\s*([\d,]+)\nRs\.\s*([\d,]+)',s,re.S)
  if match:
   ext,title,start,end,daily,total=match.groups()
  else:
   # Some long-name rows are split into two text blocks
   sm=re.match(r'^((?:VG|SS|UE|AR|MSK)-\d{2})\n(.+)$',s,re.S)
   if not sm or j+1>=len(bs):continue
   ext,title=sm.groups(); ns=bs[j+1][4].strip(); mm=re.match(r'^(\d{2} \w{3} 20\d{2})\n(\d{2} \w{3} 20\d{2})\nRs\.\s*([\d,]+)\nRs\.\s*([\d,]+)',ns)
   if not mm:continue
   start,end,daily,total=mm.groups()
  camps.append({'external_id':ext,'business':names[ext.split('-')[0]],'title':title.replace('\n',' ').strip(),'start_date':dt(start).isoformat(),'end_date':dt(end).isoformat(),'daily_budget':int(daily.replace(',','')),'planned_budget':int(total.replace(',','')),'status':'planned','objective':'See campaign video master script and verify approved offer, proof, and CTA.'})
print('CAMPAIGNS',len(camps))
def write(name,records):
 if not records:return
 with open(R/'data'/name,'w',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
write('content_import.csv',reels+posts);write('campaign_import.csv',camps)
assert len(reels)==300, f'expected 300 reel rows, got {len(reels)}'
assert len(posts)==525, f'expected 525 posts, got {len(posts)}'
assert len(camps)==34, f'expected 34 campaigns, got {len(camps)}'
